package org.example.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransactionPerMonth {
    @JsonProperty("id")
    int id;
    @JsonProperty("title")
    String title;
    @JsonProperty("price")
    double price;
    @JsonProperty("description")
    String description;
    @JsonProperty("category")
    String category;
    @JsonProperty("img")
    String img;
    @JsonProperty("sold")
    boolean sold;
    @JsonProperty("dateOfSale")
    String dateOfSale;
}
