package org.example.service;

import org.example.model.TransactionPerMonth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class GetTransactionsService {
    @Autowired
    RestTemplate restTemplate;

    public ResponseEntity<TransactionPerMonth[]> getTransactionsPerMonth(String month) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity <String> entity = new HttpEntity<String>(headers);
        ResponseEntity<TransactionPerMonth[]> response = restTemplate.exchange("https://s3.amazonaws.com/roxiler.com/product_transaction.json", HttpMethod.GET,entity,TransactionPerMonth[].class);
        System.out.printf("Hello and welcome!"+response);
        return response;
    }
}
